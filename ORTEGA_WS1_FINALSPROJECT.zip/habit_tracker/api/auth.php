<?php
require 'db.php';
$action = $_GET['action'] ?? '';

if ($action === 'me') {
    if (empty($_SESSION['uid'])) {
        out(['user' => null]);
    }
    $s = $db->prepare('SELECT username, full_name FROM users WHERE id = ?');
    $s->bind_param('i', $_SESSION['uid']);
    $s->execute();
    out(['user' => $s->get_result()->fetch_assoc()]);
}

if ($action === 'logout') {
    $_SESSION = [];
    session_destroy();
    out(['ok' => true]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    out(['error' => 'POST required.'], 405);
}
$b = body();
$username = strtolower(trim($b['username'] ?? ''));
$password = $b['password'] ?? '';

if ($action === 'register') {
    $name = trim($b['full_name'] ?? '');
    if (!preg_match('/^[a-z0-9_.]{3,20}$/', $username) || $name === '' || mb_strlen($name) > 100 || strlen($password) < 6) {
        out(['error' => 'Please check your username, full name and password (6+ characters).'], 400);
    }
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $s = $db->prepare('INSERT INTO users (username, full_name, password_hash) VALUES (?, ?, ?)');
    $s->bind_param('sss', $username, $name, $hash);
    if (!$s->execute()) {
        if ($db->errno === 1062) {
            out(['error' => 'That username is already taken. Please choose another.'], 409);
        }
        out(['error' => 'Could not create the account.'], 500);
    }
    session_regenerate_id(true);
    $_SESSION['uid'] = $db->insert_id;
    out(['user' => ['username' => $username, 'full_name' => $name]]);
}

if ($action === 'login') {
    $s = $db->prepare('SELECT id, full_name, password_hash FROM users WHERE username = ?');
    $s->bind_param('s', $username);
    $s->execute();
    $row = $s->get_result()->fetch_assoc();
    if (!$row || !password_verify($password, $row['password_hash'])) {
        out(['error' => 'Incorrect username or password.'], 401);
    }
    session_regenerate_id(true);
    $_SESSION['uid'] = (int) $row['id'];
    out(['user' => ['username' => $username, 'full_name' => $row['full_name']]]);
}

out(['error' => 'Unknown action.'], 400);
