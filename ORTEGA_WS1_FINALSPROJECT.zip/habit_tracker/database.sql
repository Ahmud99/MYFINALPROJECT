
CREATE DATABASE IF NOT EXISTS habit_tracker CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE habit_tracker;
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(20)  NOT NULL UNIQUE,
  full_name     VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categories (
  id   INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(40) NOT NULL UNIQUE
);
INSERT IGNORE INTO categories (name) VALUES
  ('Health & Fitness'), ('Learning & Education'), ('Productivity'), ('Creativity'),
  ('Mindfulness'), ('Social'), ('Finance'), ('Other');

CREATE TABLE IF NOT EXISTS activities (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  category_id   INT NULL,
  type          ENUM('habit','study','task','meal') NOT NULL,
  title         VARCHAR(150) NOT NULL,
  notes         VARCHAR(500) NULL,
  activity_date DATE NOT NULL,
  activity_time TIME NULL,
  start_time    TIME NULL,
  end_time      TIME NULL,
  priority      ENUM('Low','Medium','High') NULL,
  icon          VARCHAR(16) NULL,
  color         VARCHAR(7) NULL,
  is_done       TINYINT(1) NOT NULL DEFAULT 0,
  reminder_on   TINYINT(1) NOT NULL DEFAULT 0,
  reminder_time TIME NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_date (user_id, activity_date),
  FOREIGN KEY (user_id)     REFERENCES users(id)      ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);
